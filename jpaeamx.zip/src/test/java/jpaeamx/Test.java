package jpaeamx;

public class Test {

}
